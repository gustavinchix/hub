[![Gitpod Ready-to-Code](https://img.shields.io/badge/Gitpod-Ready--to--Code-blue?logo=gitpod)](https://gitpod.io/#https://github.com/ernestomedinam/simple-html-css-gitpodws) 

# Simple html + css gitpod workspace
Based on live server. Launches on start. Use `$ live-server` to start again if it gets stucked because of an error on code. To manually stop server, or kill it when crashed, use `Ctrl+C`.

## Espacio de trabajo en gitpod para html + css
Con base en live-server. Arranca cada inicio del espacio de trabajo. Usa `$ live-server` para arrancar de nuevo el servidor si se ha detenido por algún error en el código. Para detener el código manualmente, o matar el proceso si se ha inhibido, usa `Ctrl-C`.
